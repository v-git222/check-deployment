// // visual-regression-testing.js
// // Optimized visual regression testing tool for comparing localhost URLs against Figma screenshots
// //
// // Usage examples:
// // node visual-regression-testing.js --config visual-tests.config.json
// // node visual-regression-testing.js --url http://localhost:5173 --baseline ./figma/homepage.png
// // node visual-regression-testing.js --url http://localhost:5173 --baseline ./figma/homepage.png --selector ".hero" --threshold 0.001
// // node visual-regression-testing.js --batch --config ./tests/visual-config.json

// import { Builder } from 'selenium-webdriver';
// import chrome from 'selenium-webdriver/chrome.js';
// import fs from 'fs/promises';
// import fsSync from 'fs';
// import path from 'path';
// import pixelmatch from 'pixelmatch';
// import { PNG } from 'pngjs';
// import 'chromedriver';

// // ============================================================================
// // Configuration & Argument Parsing
// // ============================================================================

// class TestConfig {
//   constructor() {
//     this.defaultOptions = {
//       threshold: 0.001,
//       viewport: { width: 1920, height: 1080 },
//       waitTime: 1000,
//       hideSelectors: [],
//       pixelmatchThreshold: 0.1,
//       outputDir: './visual-results',
//       retries: 2,
//       timeout: 30000
//     };
//   }

//   parseArgs() {
//     const argv = process.argv.slice(2);
//     const config = { ...this.defaultOptions };
    
//     for (let i = 0; i < argv.length; i++) {
//       switch (argv[i]) {
//         case '--url':
//           config.url = argv[++i];
//           break;
//         case '--baseline':
//           config.baseline = argv[++i];
//           break;
//         case '--selector':
//           config.selector = argv[++i];
//           break;
//         case '--threshold':
//           config.threshold = parseFloat(argv[++i]);
//           break;
//         case '--viewport':
//           const [w, h] = argv[++i].split('x').map(Number);
//           config.viewport = { width: w, height: h };
//           break;
//         case '--wait':
//           config.waitTime = parseInt(argv[++i]);
//           break;
//         case '--hide':
//           config.hideSelectors = argv[++i].split(',');
//           break;
//         case '--config':
//           config.configFile = argv[++i];
//           break;
//         case '--batch':
//           config.batchMode = true;
//           break;
//         case '--output':
//           config.outputDir = argv[++i];
//           break;
//         case '--update-baseline':
//           config.updateBaseline = true;
//           break;
//         case '--name':
//           config.testName = argv[++i];
//           break;
//         default:
//           break;
//       }
//     }

//     return config;
//   }

//   async loadConfigFile(filePath) {
//     try {
//       const content = await fs.readFile(filePath, 'utf8');
//       return JSON.parse(content);
//     } catch (err) {
//       throw new Error(`Failed to load config file ${filePath}: ${err.message}`);
//     }
//   }

//   async resolveConfig() {
//     const args = this.parseArgs();
    
//     if (args.configFile) {
//       const fileConfig = await this.loadConfigFile(args.configFile);
//       return { ...this.defaultOptions, ...fileConfig, ...args };
//     }
    
//     if (!args.url && !args.batchMode) {
//       this.showUsage();
//       process.exit(1);
//     }
    
//     return args;
//   }

//   showUsage() {
//     console.log(`
// Visual Regression Testing Tool
// ==============================

// Single Test Mode:
//   node visual-regression-testing.js --url <url> --baseline <path> [options]

// Batch Mode:
//   node visual-regression-testing.js --config <config.json> [--batch]

// Options:
//   --url              Target URL to test (e.g., http://localhost:5173)
//   --baseline         Path to Figma screenshot PNG
//   --selector         CSS selector to screenshot specific element
//   --threshold        Diff threshold (0-1, default: 0.001)
//   --viewport         Viewport size (e.g., 1920x1080)
//   --wait             Wait time after page load in ms (default: 1000)
//   --hide             Comma-separated selectors to hide (e.g., ".ads,.timestamp")
//   --output           Output directory for results (default: ./visual-results)
//   --update-baseline  Update baseline with current screenshot
//   --name             Test name for reports
//   --config           Path to JSON config file
//   --batch            Run all tests from config file

// Config File Format (JSON):
// {
//   "tests": [
//     {
//       "name": "Homepage Hero",
//       "url": "http://localhost:5173",
//       "baseline": "./figma/homepage-hero.png",
//       "selector": ".hero",
//       "threshold": 0.001
//     }
//   ],
//   "viewport": { "width": 1920, "height": 1080 },
//   "waitTime": 1000,
//   "hideSelectors": [".ads", ".timestamp"]
// }
// `);
//   }
// }

// // ============================================================================
// // Screenshot & Image Processing
// // ============================================================================

// class ImageProcessor {
//   static cropCenter(pngIn, targetW, targetH) {
//     const srcW = pngIn.width;
//     const srcH = pngIn.height;
//     const startX = Math.max(0, Math.floor((srcW - targetW) / 2));
//     const startY = Math.max(0, Math.floor((srcH - targetH) / 2));
//     const out = new PNG({ width: targetW, height: targetH });
    
//     for (let y = 0; y < targetH; y++) {
//       const srcStart = ((y + startY) * srcW + startX) * 4;
//       const srcEnd = srcStart + targetW * 4;
//       const row = pngIn.data.slice(srcStart, srcEnd);
//       out.data.set(row, y * targetW * 4);
//     }
    
//     return out;
//   }

//   static async takeScreenshot(driver, selector = null) {
//     if (selector) {
//       try {
//         const el = await driver.findElement({ css: selector });
//         if (typeof el.takeScreenshot === 'function') {
//           const b64 = await el.takeScreenshot(true);
//           return Buffer.from(b64, 'base64');
//         } else {
//           console.warn('⚠️  Element screenshot not supported, using viewport screenshot');
//         }
//       } catch (err) {
//         console.warn(`⚠️  Selector "${selector}" not found, using viewport screenshot`);
//       }
//     }
    
//     const b64 = await driver.takeScreenshot();
//     return Buffer.from(b64, 'base64');
//   }

//   static async hideElements(driver, selectors) {
//     if (!selectors || selectors.length === 0) return;
    
//     const script = `
//       const selectors = ${JSON.stringify(selectors)};
//       selectors.forEach(sel => {
//         document.querySelectorAll(sel).forEach(el => {
//           if (el) el.style.visibility = 'hidden';
//         });
//       });
//     `;
    
//     try {
//       await driver.executeScript(script);
//       console.log(`✓ Hidden elements: ${selectors.join(', ')}`);
//     } catch (err) {
//       console.warn(`⚠️  Failed to hide elements: ${err.message}`);
//     }
//   }

//   static compareImages(baseline, actual, config) {
//     const baselinePNG = PNG.sync.read(baseline);
//     const actualPNG = PNG.sync.read(actual);

//     // Determine common compare area
//     const commonW = Math.min(baselinePNG.width, actualPNG.width);
//     const commonH = Math.min(baselinePNG.height, actualPNG.height);

//     if (commonW <= 0 || commonH <= 0) {
//       throw new Error(
//         `Invalid dimensions: baseline ${baselinePNG.width}x${baselinePNG.height}, ` +
//         `actual ${actualPNG.width}x${actualPNG.height}`
//       );
//     }

//     const baselineCropped = 
//       (baselinePNG.width === commonW && baselinePNG.height === commonH)
//         ? baselinePNG
//         : this.cropCenter(baselinePNG, commonW, commonH);

//     const actualCropped = 
//       (actualPNG.width === commonW && actualPNG.height === commonH)
//         ? actualPNG
//         : this.cropCenter(actualPNG, commonW, commonH);

//     const diff = new PNG({ width: commonW, height: commonH });
//     const mismatch = pixelmatch(
//       baselineCropped.data,
//       actualCropped.data,
//       diff.data,
//       commonW,
//       commonH,
//       { threshold: config.pixelmatchThreshold }
//     );

//     return {
//       mismatch,
//       totalPixels: commonW * commonH,
//       ratio: mismatch / (commonW * commonH),
//       diff,
//       dimensions: {
//         baseline: { width: baselinePNG.width, height: baselinePNG.height },
//         actual: { width: actualPNG.width, height: actualPNG.height },
//         compared: { width: commonW, height: commonH }
//       }
//     };
//   }
// }

// // ============================================================================
// // Test Runner
// // ============================================================================

// class VisualTestRunner {
//   constructor(config) {
//     this.config = config;
//     this.driver = null;
//     this.results = [];
//   }

//   async initialize() {
//     const options = new chrome.Options();
//     options.addArguments(
//       '--headless=new',
//       '--disable-gpu',
//       '--no-sandbox',
//       '--disable-dev-shm-usage',
//       `--window-size=${this.config.viewport.width},${this.config.viewport.height}`
//     );

//     this.driver = await new Builder()
//       .forBrowser('chrome')
//       .setChromeOptions(options)
//       .build();

//     await this.driver.manage().setTimeouts({ implicit: this.config.timeout });

//     // Ensure output directory exists
//     await fs.mkdir(this.config.outputDir, { recursive: true });
//   }

//   async cleanup() {
//     if (this.driver) {
//       await this.driver.quit();
//     }
//   }

//   async runTest(test, retryCount = 0) {
//     const testName = test.name || path.basename(test.baseline, '.png');
//     console.log(`\n${'='.repeat(60)}`);
//     console.log(`Running: ${testName}`);
//     console.log(`${'='.repeat(60)}`);

//     try {
//       // Navigate to URL
//       console.log(`→ Loading ${test.url}...`);
//       await this.driver.get(test.url);
//       await this.driver.sleep(test.waitTime || this.config.waitTime);

//       // Hide dynamic elements
//       if (test.hideSelectors || this.config.hideSelectors) {
//         const selectors = [
//           ...(this.config.hideSelectors || []),
//           ...(test.hideSelectors || [])
//         ];
//         await ImageProcessor.hideElements(this.driver, selectors);
//       }

//       // Take screenshot
//       console.log(`→ Capturing screenshot...`);
//       const actualBuffer = await ImageProcessor.takeScreenshot(
//         this.driver,
//         test.selector
//       );

//       // Save actual screenshot
//       const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
//       const actualPath = path.join(
//         this.config.outputDir,
//         `${testName.replace(/\s+/g, '-')}_actual_${timestamp}.png`
//       );
//       await fs.writeFile(actualPath, actualBuffer);
//       console.log(`✓ Saved actual: ${actualPath}`);

//       // Check if baseline exists
//       if (!fsSync.existsSync(test.baseline)) {
//         if (this.config.updateBaseline) {
//           await fs.mkdir(path.dirname(test.baseline), { recursive: true });
//           await fs.writeFile(test.baseline, actualBuffer);
//           console.log(`✓ Created baseline: ${test.baseline}`);
//           return { status: 'baseline-created', test: testName };
//         } else {
//           throw new Error(`Baseline not found: ${test.baseline}. Use --update-baseline to create it.`);
//         }
//       }

//       // Update baseline if requested
//       if (this.config.updateBaseline) {
//         await fs.writeFile(test.baseline, actualBuffer);
//         console.log(`✓ Updated baseline: ${test.baseline}`);
//         return { status: 'baseline-updated', test: testName };
//       }

//       // Compare images
//       console.log(`→ Comparing with baseline...`);
//       const baselineBuffer = await fs.readFile(test.baseline);
//       const comparison = ImageProcessor.compareImages(
//         baselineBuffer,
//         actualBuffer,
//         { ...this.config, ...test }
//       );

//       // Save diff image
//       const diffPath = path.join(
//         this.config.outputDir,
//         `${testName.replace(/\s+/g, '-')}_diff_${timestamp}.png`
//       );
//       await fs.writeFile(diffPath, PNG.sync.write(comparison.diff));

//       const threshold = test.threshold || this.config.threshold;
//       const passed = comparison.ratio <= threshold;

//       console.log(`\nResults:`);
//       console.log(`  Baseline: ${comparison.dimensions.baseline.width}x${comparison.dimensions.baseline.height}`);
//       console.log(`  Actual:   ${comparison.dimensions.actual.width}x${comparison.dimensions.actual.height}`);
//       console.log(`  Compared: ${comparison.dimensions.compared.width}x${comparison.dimensions.compared.height}`);
//       console.log(`  Mismatch: ${comparison.mismatch} / ${comparison.totalPixels} pixels`);
//       console.log(`  Ratio:    ${(comparison.ratio * 100).toFixed(4)}%`);
//       console.log(`  Threshold: ${(threshold * 100).toFixed(4)}%`);

//       if (passed) {
//         console.log(`\n✅ PASS`);
//         return {
//           status: 'passed',
//           test: testName,
//           ratio: comparison.ratio,
//           threshold
//         };
//       } else {
//         console.log(`\n❌ FAIL`);
//         console.log(`   Diff saved: ${diffPath}`);
//         return {
//           status: 'failed',
//           test: testName,
//           ratio: comparison.ratio,
//           threshold,
//           diffPath
//         };
//       }
//     } catch (err) {
//       if (retryCount < this.config.retries) {
//         console.warn(`⚠️  Test failed, retrying (${retryCount + 1}/${this.config.retries})...`);
//         await this.driver.sleep(1000);
//         return this.runTest(test, retryCount + 1);
//       }
      
//       console.error(`\n❌ ERROR: ${err.message}`);
//       return {
//         status: 'error',
//         test: testName,
//         error: err.message
//       };
//     }
//   }

//   async run() {
//     try {
//       await this.initialize();

//       if (this.config.batchMode && this.config.tests) {
//         // Batch mode - run multiple tests
//         console.log(`\n🚀 Running ${this.config.tests.length} visual tests...\n`);
        
//         for (const test of this.config.tests) {
//           const result = await this.runTest(test);
//           this.results.push(result);
//         }
        
//         this.printSummary();
//       } else {
//         // Single test mode
//         const test = {
//           url: this.config.url,
//           baseline: this.config.baseline,
//           selector: this.config.selector,
//           threshold: this.config.threshold,
//           hideSelectors: this.config.hideSelectors,
//           waitTime: this.config.waitTime,
//           name: this.config.testName
//         };
        
//         const result = await this.runTest(test);
//         this.results.push(result);
//       }

//       await this.generateReport();
      
//       // Exit with appropriate code
//       const failed = this.results.filter(r => r.status === 'failed' || r.status === 'error');
//       process.exit(failed.length > 0 ? 1 : 0);
      
//     } catch (err) {
//       console.error('Fatal error:', err);
//       process.exit(2);
//     } finally {
//       await this.cleanup();
//     }
//   }

//   printSummary() {
//     console.log(`\n${'='.repeat(60)}`);
//     console.log('TEST SUMMARY');
//     console.log(`${'='.repeat(60)}`);
    
//     const passed = this.results.filter(r => r.status === 'passed').length;
//     const failed = this.results.filter(r => r.status === 'failed').length;
//     const errors = this.results.filter(r => r.status === 'error').length;
//     const other = this.results.filter(r => 
//       !['passed', 'failed', 'error'].includes(r.status)
//     ).length;
    
//     console.log(`Total:   ${this.results.length}`);
//     console.log(`✅ Passed: ${passed}`);
//     console.log(`❌ Failed: ${failed}`);
//     console.log(`⚠️  Errors: ${errors}`);
//     if (other > 0) console.log(`ℹ️  Other:  ${other}`);
    
//     if (failed > 0) {
//       console.log(`\nFailed Tests:`);
//       this.results
//         .filter(r => r.status === 'failed')
//         .forEach(r => {
//           console.log(`  • ${r.test} (${(r.ratio * 100).toFixed(4)}% > ${(r.threshold * 100).toFixed(4)}%)`);
//         });
//     }
//   }

//   async generateReport() {
//     const reportPath = path.join(this.config.outputDir, 'report.json');
//     const report = {
//       timestamp: new Date().toISOString(),
//       config: this.config,
//       results: this.results,
//       summary: {
//         total: this.results.length,
//         passed: this.results.filter(r => r.status === 'passed').length,
//         failed: this.results.filter(r => r.status === 'failed').length,
//         errors: this.results.filter(r => r.status === 'error').length
//       }
//     };
    
//     await fs.writeFile(reportPath, JSON.stringify(report, null, 2));
//     console.log(`\n📊 Report saved: ${reportPath}`);
//   }
// }

// // ============================================================================
// // Main Execution
// // ============================================================================

// async function main() {
//   const configManager = new TestConfig();
//   const config = await configManager.resolveConfig();
//   const runner = new VisualTestRunner(config);
//   await runner.run();
// }

// main().catch(err => {
//   console.error('Unhandled error:', err);
//   process.exit(2);
// });