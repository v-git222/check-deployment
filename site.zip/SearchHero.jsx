// SearchHero.jsx
import React, { useState, useRef, useEffect } from "react";
import TrendingCard from "./TrendingCard";
import "./SearchHero.css";


const CATEGORY_OPTIONS = ["All", "Startups", "Tokens", "Investors"];


export default function SearchHero({ initialItems }) {
const [active, setActive] = useState(null);
const [query, setQuery] = useState("");
const [open, setOpen] = useState(false);
const [filtered, setFiltered] = useState(
initialItems || [
{ title: "AI & Machine Learning Startups", pct: "+156%" },
{ title: "Renewable Energy Projects", pct: "+89%" },
{ title: "Healthcare Technology", pct: "+67%" },
]
);


/* combobox state */
const [category, setCategory] = useState(CATEGORY_OPTIONS[0]);
const [catOpen, setCatOpen] = useState(false);
const [catHighlight, setCatHighlight] = useState(0);


const containerRef = useRef(null);
const inputRef = useRef(null);
const cdControlRef = useRef(null);


useEffect(() => {
const base =
initialItems && initialItems.length
? initialItems
: [
{ title: "AI & Machine Learning Startups", pct: "+156%" },
{ title: "Renewable Energy Projects", pct: "+89%" },
{ title: "Healthcare Technology", pct: "+67%" },
];


const q = query.trim().toLowerCase();
setFiltered(q ? base.filter((it) => it.title.toLowerCase().includes(q)) : base);
}, [query, initialItems]);


useEffect(() => {
function onDocClick(e) {
if (!containerRef.current?.contains(e.target)) {
setOpen(false);
setCatOpen(false);
}
}
document.addEventListener("mousedown", onDocClick);
return () => document.removeEventListener("mousedown", onDocClick);
}, []);


const toggleActiveButton = (name) => setActive((prev) => (prev === name ? null : name));


const handleInputKeyDown = (e) => {
if (e.key === "Enter") {
e.preventDefault();
if (filtered.length > 0) selectItem(filtered[0]);
setOpen(false);
} else if (e.key === "Escape") {
setOpen(false);
inputRef.current?.blur();
}
};


const selectItem = (item) => {
setQuery(item.title);
setOpen(false);
console.log("Selected suggestion:", item.title);
};


const onCatKeyDown = (e) => {
const max = CATEGORY_OPTIONS.length - 1;
}}