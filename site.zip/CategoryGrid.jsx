import React, { useState } from "react";
import "./CategoryGrid.css";
import CategoryOverlay from "./CategoryOverlay";

// SVG imports (you already had these)
import tech from "./assets/nano-technology.svg";
import realest from "./assets/real-estate.svg";
import health from "./assets/healthcare.svg";
import ai from "./assets/ai.svg";
import ecom from "./assets/ecommerce.svg";
import event from "./assets/fashion.svg";

const CATEGORY_META = [
  { id: 1, name: "Technology", opportunities: 634, tone: "tech" },
  { id: 2, name: "Real Estate", opportunities: 634, tone: "green" },
  { id: 3, name: "Healthcare", opportunities: 634, tone: "red" },
  { id: 4, name: "AI & Machine Learning", opportunities: 634, tone: "purple" },
  { id: 5, name: "E-Commerce", opportunities: 634, tone: "teal" },
  { id: 6, name: "Fashion & Beauty", opportunities: 634, tone: "pink" },
];

// Map category name -> imported SVG
const ICON_MAP = {
  Technology: tech,
  "Real Estate": realest,
  Healthcare: health,
  "AI & Machine Learning": ai,
  "E-Commerce": ecom,
  "Fashion & Beauty": event,
};

  function Icon({ name, tone, size = 36 }) {
    const colors = {
      tech: "#6366F1",
      green: "#10B981",
      red: "#EF4444",
      purple: "#8B5CF6",
      teal: "#0891B2",
      pink: "#F472B6",
    };
    // const stroke = colors[tone] || "#6366F1";

    const src = ICON_MAP[name];

    // If we have an imported SVG file, use it.
    if (src) {
      return (
        <img
          src={src}
          alt={`${name} icon`}
          width={size}
          height={size}
          style={{ display: "block" }}
          draggable="false"
        />
      );
    }

    // Fallback: simple inline SVG (no external dependency)
    return (
      <svg
        className="cg-icon-svg"
        viewBox="0 0 24 24"
        width={size}
        height={size}
        aria-hidden="true"
        role="img"
      >
        <rect
          x="3"
          y="3"
          width="18"
          height="18"
          rx="4"
          stroke={stroke}
          strokeWidth="1.6"
          fill="none"
        />
        <path d="M8 12h8" stroke={stroke} strokeWidth="1.4" strokeLinecap="round" />
      </svg>
    );
  }

export default function CategoryGrid() {
  const [selected, setSelected] = useState(new Set([2, 5]));

  const toggle = (id) => {
    setSelected((prev) => {
      const copy = new Set(prev);
      copy.has(id) ? copy.delete(id) : copy.add(id);
      return copy;
    });
  };

  const clearAll = () => setSelected(new Set());
  const continueAction = () => {
    // Replace with actual navigation/handler
    alert(`Continue (selected ${selected.size})`);
  };

  return (
    <section className="cg-frame">
      <div className="cg-heading-wrap">
        <h3 className="cg-heading">Pick your Category to start</h3>
      </div>

      <div className="avatar-img-purple">
        <img src="/ArrowPurple.png" alt="Arrow Purple" />
      </div>
      <div className="avatar-img-yellow">
        <img src="/ArrowYellow.png" alt="Arrow Yellow" />
      </div>

      <div className="cg-grid-wrap">
        <div className="cg-grid" role="list" aria-label="category list">
          {CATEGORY_META.map((c) => {
            const isSelected = selected.has(c.id);
            return (
              <article
                key={c.id}
                className={`cg-card ${isSelected ? "selected" : ""}`}
                role="listitem"
              >
                <div className="cg-card-top">
                  <div className={`cg-icon ${c.tone}`}>
                    <Icon name={c.name} tone={c.tone} size={36} />
                  </div>

                  <button
                    type="button"
                    className={`cg-toggle ${isSelected ? "on" : "off"}`}
                    aria-pressed={isSelected}
                    aria-label={`${isSelected ? "Deselect" : "Select"} ${c.name}`}
                    onClick={(e) => {
                      e.stopPropagation();
                      toggle(c.id);
                    }}
                    onKeyDown={(e) => {
                      if (e.key === " " || e.key === "Spacebar" || e.key === "Enter") {
                        e.preventDefault();
                        e.stopPropagation();
                        toggle(c.id);
                      }
                    }}
                  />
                </div>

                <div className="cg-card-body">
                  <h4 className="cg-title">{c.name}</h4>
                  <p className="cg-sub">{c.opportunities} Opportunities</p>
                </div>
              </article>
            );
          })}

          <div
            className="cg-card cg-browse"
            role="button"
            tabIndex={0}
            onClick={() => alert("Open category browser")}
            onKeyDown={(e) => {
              if (e.key === "Enter" || e.key === " ") {
                e.preventDefault();
                alert("Open category browser");
              }
            }}
          >
            <div className="cg-icon gray">
              {/* Simple grid icon as inline SVG fallback for "browse" */}
              <svg viewBox="0 0 24 24" width="36" height="36" aria-hidden="true">
                <g fill="#9CA3AF">
                  <circle cx="6" cy="6" r="2"></circle>
                  <circle cx="12" cy="6" r="2"></circle>
                  <circle cx="18" cy="6" r="2"></circle>
                  <circle cx="6" cy="12" r="2"></circle>
                  <circle cx="12" cy="12" r="2"></circle>
                  <circle cx="18" cy="12" r="2"></circle>
                </g>
              </svg>
            </div>
            <div className="cg-card-body">
              <h4 className="cg-title">Browse Category</h4>
              <p className="cg-sub" style={{ marginTop: 8 }}></p>
            </div>
          </div>
        </div>

        <CategoryOverlay />

        {/* Footer with count + actions */}
        <div className="cg-footer" aria-hidden={false}>
          <div className="cg-selected-count">{selected.size} categories selected</div>

          <div className="cg-actions">
            <button
              className="cg-clear-btn"
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                clearAll();
              }}
            >
              Clear all
            </button>

            <button
              className="cg-primary-btn"
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                continueAction();
              }}
            >
              Continue
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}
